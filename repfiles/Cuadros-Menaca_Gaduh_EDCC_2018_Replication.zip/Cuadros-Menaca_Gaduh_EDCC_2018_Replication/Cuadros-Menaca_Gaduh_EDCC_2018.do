//****************************************************************************//
*        Remittances, Child Labor, and Schooling:Evidence from Colombia        *
*             Constructed by Andres Cuadros-Menaca and Arya Gaduh              *
*                Economic Development and Cultural Change (2018)               *
//****************************************************************************//

//Directory

global d_user "your directory"
use "$d_user\Remit_Child_School", clear

//Table 1

*Economic activity

eststo wholesaleall: estpost sum wholesale if age<=18 & sample & h==1
eststo wholesaleboy: estpost sum wholesale if age<=18 & sample & h==1 & boy==1
eststo wholesalegirl: estpost sum wholesale if age<=18 & sample & h==1 & boy==0
eststo wholesale14: estpost sum wholesale if age<=14 & sample & h==1 
eststo wholesale16: estpost sum wholesale if age>14 & age<=16 & sample & h==1 
eststo wholesale18: estpost sum wholesale if age>16 & age<=18 & sample & h==1

esttab wholesaleall wholesaleboy wholesalegirl wholesale14 wholesale16 wholesale18 ///
    using "$d_user/wholesale", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)
	
eststo hotelsall: estpost sum hotels if age<=18 & sample & h==1
eststo hotelsboy: estpost sum hotels if age<=18 & sample & h==1 & boy==1
eststo hotelsgirl: estpost sum hotels if age<=18 & sample & h==1 & boy==0
eststo hotels14: estpost sum hotels if age<=14 & sample & h==1 
eststo hotels16: estpost sum hotels if age>14 & age<=16 & sample & h==1 
eststo hotels18: estpost sum hotels if age>16 & age<=18 & sample & h==1

esttab hotelsall hotelsboy hotelsgirl hotels14 hotels16 hotels18 ///
    using "$d_user/hotels", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)	
	
eststo manufactureall: estpost sum manufacture if age<=18 & sample & h==1
eststo manufactureboy: estpost sum manufacture if age<=18 & sample & h==1 & boy==1
eststo manufacturegirl: estpost sum manufacture if age<=18 & sample & h==1 & boy==0
eststo manufacture14: estpost sum manufacture if age<=14 & sample & h==1 
eststo manufacture16: estpost sum manufacture if age>14 & age<=16 & sample & h==1 
eststo manufacture18: estpost sum manufacture if age>16 & age<=18 & sample & h==1

esttab manufactureall manufactureboy manufacturegirl manufacture14 manufacture16 manufacture18 ///
    using "$d_user/manufacture", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)
	
eststo transportationall: estpost sum transportation if age<=18 & sample & h==1
eststo transportationboy: estpost sum transportation if age<=18 & sample & h==1 & boy==1
eststo transportationgirl: estpost sum transportation if age<=18 & sample & h==1 & boy==0
eststo transportation14: estpost sum transportation if age<=14 & sample & h==1 
eststo transportation16: estpost sum transportation if age>14 & age<=16 & sample & h==1 
eststo transportation18: estpost sum transportation if age>16 & age<=18 & sample & h==1

esttab transportationall transportationboy transportationgirl transportation14 transportation16 transportation18 ///
    using "$d_user/transportation", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)
	
eststo otherall: estpost sum other_services if age<=18 & sample & h==1
eststo otherboy: estpost sum other_services if age<=18 & sample & h==1 & boy==1
eststo othergirl: estpost sum other_services if age<=18 & sample & h==1 & boy==0
eststo other14: estpost sum other_services if age<=14 & sample & h==1 
eststo other16: estpost sum other_services if age>14 & age<=16 & sample & h==1 
eststo other18: estpost sum other_services if age>16 & age<=18 & sample & h==1

esttab otherall otherboy othergirl other14 other16 other18 ///
    using "$d_user/other", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)
	
eststo constructionall: estpost sum construction if age<=18 & sample & h==1
eststo constructionboy: estpost sum construction if age<=18 & sample & h==1 & boy==1
eststo constructiongirl: estpost sum construction if age<=18 & sample & h==1 & boy==0
eststo construction14: estpost sum construction if age<=14 & sample & h==1 
eststo construction16: estpost sum construction if age>14 & age<=16 & sample & h==1 
eststo construction18: estpost sum construction if age>16 & age<=18 & sample & h==1

esttab constructionall constructionboy constructiongirl construction14 construction16 construction18 ///
    using "$d_user/construction", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)
	
eststo domesticall: estpost sum domestic if age<=18 & sample & h==1
eststo domesticboy: estpost sum domestic if age<=18 & sample & h==1 & boy==1
eststo domesticgirl: estpost sum domestic if age<=18 & sample & h==1 & boy==0
eststo domestic14: estpost sum domestic if age<=14 & sample & h==1 
eststo domestic16: estpost sum domestic if age>14 & age<=16 & sample & h==1 
eststo domestic18: estpost sum domestic if age>16 & age<=18 & sample & h==1

esttab domesticall domesticboy domesticgirl domestic14 domestic16 domestic18 ///
    using "$d_user/domestic", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

eststo othersall: estpost sum others if age<=18 & sample & h==1
eststo othersboy: estpost sum others if age<=18 & sample & h==1 & boy==1
eststo othersgirl: estpost sum others if age<=18 & sample & h==1 & boy==0
eststo others14: estpost sum others if age<=14 & sample & h==1 
eststo others16: estpost sum others if age>14 & age<=16 & sample & h==1 
eststo others18: estpost sum others if age>16 & age<=18 & sample & h==1

esttab othersall othersboy othersgirl others14 others16 others18 ///
    using "$d_user/others", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)	

*Hours worked

eststo avghoursall: estpost sum hours if age<=18 & sample & hours>0
eststo avghoursboy: estpost sum hours if age<=18 & sample & hours>0 & boy==1
eststo avghoursgirl: estpost sum hours if age<=18 & sample & hours>0 & boy==0
eststo avghours14: estpost sum hours if age<=14 & sample & hours>0
eststo avghours16: estpost sum hours if age>=15 & age<=16 & sample & hours>0 
eststo avghours18: estpost sum hours if age>=17 & age<=18 & sample & hours>0

esttab avghoursall avghoursboy avghoursgirl avghours14 avghours16 avghours18 ///
    using "$d_user/averagehours", replace label fragment booktabs cells(mean(fmt(2))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

*Attending school

eststo work_studyall: estpost sum edu if age<=18 & sample & h==1
eststo work_studyboy: estpost sum edu if age<=18 & sample & h==1 & boy==1
eststo work_studygirl: estpost sum edu if age<=18 & sample & h==1 & boy==0
eststo work_study14: estpost sum edu if age<=14 & sample & h==1
eststo work_study16: estpost sum edu if age>=15 & age<=16 & sample & h==1
eststo work_study18: estpost sum edu if age>=17 & age<=18 & sample & h==1

esttab work_studyall work_studyboy work_studygirl work_study14 work_study16 work_study18 ///
    using "$d_user/work_study", replace label fragment booktabs cells(mean(fmt(2))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

*Housework

eststo work_homeall: estpost sum housework if age<=18 & sample & h==1
eststo work_homeboy: estpost sum housework if age<=18 & sample & h==1 & boy==1
eststo work_homegirl: estpost sum housework if age<=18 & sample & h==1 & boy==0
eststo work_home14: estpost sum housework if age<=14 & sample & h==1
eststo work_home16: estpost sum housework if age>=15 & age<=16 & sample & h==1
eststo work_home18: estpost sum housework if age>=17 & age<=18 & sample & h==1

esttab work_homeall work_homeboy work_homegirl work_home14 work_home16 work_home18 ///
    using "$d_user/averagework_home", replace label fragment booktabs cells(mean(fmt(2))) ///
	varwidth(15) mlabels(, none) collabels(none, none) nonumbers plain substitute(_ \_ ) style(tex)	
	
//Table 2

*LPM

eststo outcomevar1: estpost sum h edu if age<=18 & sample & recipient==1
eststo outcomevar2: estpost sum h edu if age<=18 & sample & recipient==0

esttab outcomevar1 outcomevar2 ///
    using "$d_user/averageoutcomes", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

*Tobit

eststo outcomevarhours1: estpost sum hours if hours>0 & age<=18 & sample & recipient==1
eststo outcomevarhours2: estpost sum hours if hours>0 & age<=18 & sample & recipient==0

esttab outcomevarhours1 outcomevarhours2 ///
    using  "$d_user/averageoutcomeshours", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

*Housework

eststo houseworkshare1: estpost sum housework if age<=18 & sample & recipient==1
eststo houseworkshare2: estpost sum housework if age<=18 & sample & recipient==0

esttab houseworkshare1 houseworkshare2 ///
    using "$d_user/averagehouseworkshares", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

*Child characteristics

eststo childrenvar1: estpost sum age boy hh_spouse if age<=18 & sample & recipient==1
eststo childrenvar2: estpost sum age boy hh_spouse if age<=18 & sample & recipient==0

esttab childrenvar1 childrenvar2 using "$d_user/averagechildchars", replace label ///
	fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

*Household characteristics

eststo householdvar1: estpost sum members tchildren remittances index if age<=18 & sample & recipient==1
eststo householdvar2: estpost sum members tchildren remittances index if age<=18 & sample & recipient==0

esttab householdvar1 householdvar2 ///
    using "$d_user/averagehouseholdchars.tex", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

*Household-head characteristics

eststo householdheadvar1: estpost sum femalehh marriedhh hhedu if age<=18 & sample & recipient==1
eststo householdheadvar2: estpost sum femalehh marriedhh hhedu if age<=18 & sample & recipient==0

esttab householdheadvar1 householdheadvar2 ///
    using "$d_user/averagehouseholdheadchars", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)
	
//Table 3

ge mede = region==5    //Medellin 
ge barr = region==8 // Barranquilla
ge bogo = region==11 // Bogota
ge cart = region==13 // Cartagena
ge mani = region==17 // Manizales
ge mont = region==23 // monteria
ge vill = region==50 // Villavicencio
ge pere = region==66 // pereira
ge cucu = region==54 // Cucuta
ge past = region==52 // pasto
ge buca = region==68 // Bucaramanga
ge ibag = region==73 // IbaguÈ
ge cali = region==76 // Cali

global x_variables age boy members tchildren femalehh marriedhh hhedu index hh_spouse
global FE mede barr bogo cart mani mont vill pere cucu past buca ibag cali
global region_var gini unemployment gdp 
egen region_month_year = group(region month year)

eststo alltreatment: reg remittances shock_treath shock_treatm shock_treatl $x_variables $FE $region_var ///
 if (pere==1| cali==1 | mede==1 | bogo==1 | vill==1| mani==1 | barr==1 | buca==1 | ibag==1 | cart==1 | mont==1 | past==1 | cucu==1) & age<=18 & sample, noconstant cluster(region_month_year) 
eststo hightreat_mediumtreat: reg remittances shock_treath shock_treatm  $x_variables $FE $region_var ///
 if (pere==1| cali==1 | cucu==1 | buca==1 | mede==1| bogo==1 | mont==1 | past==1 | mani==1 | cart==1) & age<=18 & sample, noconstant cluster(region_month_year) 
eststo lowtreatment: reg remittances shock_treatl  $x_variables $FE $region_var ///
if (vill==1 | ibag==1 | barr==1 | cart==1 |  mont==1 | past==1 | mani==1) & age<=18 & sample, noconstant cluster(region_month_year) 

esttab alltreatment hightreat_mediumtreat lowtreatment ///
    using  "$d_user/remittances_shock", replace label nomtitle cells(b(fmt(3)) se(par star fmt(3))) ///
    keep(shock_treath shock_treatm shock_treatl) fragment booktabs starlevels(* 0.1 ** 0.05 *** 0.01) ///
    varwidth(15) mlabels(, none) collabels(, none) substitute(_ \_ ) style(tex) 	
						
//Table 4

*Panel A

eststo ols1: reg h remit $FE if age<=18 & sample, cluster(region_month_year)  
eststo ols2: reg h remit $FE $x_variables $region_var if age<=18 & sample, cluster(region_month_year)  


capture program drop bootTobit
program define bootTobit, rclass
	
	local numctl : word count $control
	local sigIdx= `numctl' + 3
	quietly tobit $dep $endog $control $IFF, ll(0) cluster(region_month_year)	
	cap drop y2hat
	quietly predict y2hat $IFF     
	quietly matrix beta = e(b)
	local sigma = el(beta,1, `sigIdx')   
	quietly summarize y2hat $IFF
	local meany2hat = r(mean)
	local PHI = normal(`meany2hat'/`sigma')
	return scalar APEremit = `PHI'*el(beta,1,1)
end

	global dep hours
	global endog remit
	global control mede barr bogo cart mani mont vill pere cucu past buca ibag cali
	global reps 500
	global seed 2016
	global IFF if age<=18 & sample
	
	preserve 
	keep $IFF
	eststo Tobit1: bootstrap remit=r(APEremit), reps($reps) seed($seed) cluster(region_month_year): bootTobit
	estimates save "$d_user/Tobit1", replace
	global control age boy members tchildren femalehh marriedhh hhedu index hh_spouse unemployment gini gdp mede barr bogo cart mani mont vill pere cucu past buca ibag cali
	eststo Tobit2: bootstrap remit=r(APEremit), reps($reps) seed($seed) cluster(region_month_year): bootTobit	
	estimates save "$d_user/Tobit2", replace
	restore
	
eststo olsedu1: reg edu remit $FE if age<=18 & sample, cluster(region_month_year)  
eststo olsedu2: reg edu remit $FE $x_variables $region_var if age<=18 & sample, cluster(region_month_year)  	
	
esttab ols1 ols2 Tobit1 Tobit2 olsedu1 olsedu2 using "$d_user/childrenNonIV", replace label ///
	cells(b(fmt(4)) se(par star fmt(4))) keep(remit) fragment booktabs ///
	starlevels(* 0.1 ** 0.05 *** 0.01) varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain ///
	substitute(_ \_ ) style(tex)

*Panel C

eststo fstage1: reg remittances UnempShock $FE if age<=18 & sample, noconstant cluster(region_month_year)  
eststo fstage2: reg remittances UnempShock $FE $x_variables $region_var if age<=18 & sample, noconstant cluster(region_month_year)  

esttab fstage1 fstage2 fstage1 fstage2 fstage1 fstage2 ///
    using "$d_user/childrenfstage", replace label cells(b(fmt(3)) se(par star fmt(3))) keep(UnempShock) fragment booktabs ///
	starlevels(* 0.1 ** 0.05 *** 0.01) varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

*Panel B

eststo childrenLPMEcu1:  weakiv ivreg2 h $FE (remit = UnempShock) if age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd
eststo childrenLPMEcu: weakiv ivreg2 h $FE $x_variables $region_var (remit = UnempShock) if age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd
gen sampChild =e(sample)
bys HHid: egen sampHH=max(sampChild)

capture program drop bootIVTobit
program define bootIVTobit, rclass
	
	local numctl : word count $control
	local sigIdx= `numctl' + 4
	
	quietly reg $endog $iv $control $IFF, cluster(region_month_year)
	cap drop v2hat
	quietly predict v2hat $IFF, residuals
	
	quietly tobit $dep $endog $control v2hat $IFF, ll(0) cluster(region_month_year)	
	cap drop y2hat
	quietly predict y2hat $IFF     

	quietly matrix beta = e(b)
	local sigma = el(beta,1, `sigIdx')   

	quietly summarize y2hat $IFF
	local meany2hat = r(mean)
	local PHI = normal(`meany2hat'/`sigma')

	return scalar APEremit = `PHI'*el(beta,1,1)

end

	global dep hours
	global endog remit
	global iv UnempShock
	global control mede barr bogo cart mani mont vill pere cucu past buca ibag cali
	global reps 500
	global seed 2016

	global IFF if age<=18 & sample
	preserve 
	keep $IFF
	eststo childrenTobitIV1: bootstrap remit=r(APEremit), reps($reps) seed($seed) cluster(region_month_year): bootIVTobit
	estimates save "$d_user/ChildrenTobitIV1", replace
	global control age boy members tchildren femalehh marriedhh hhedu index hh_spouse unemployment gini gdp mede barr bogo cart mani mont vill pere cucu past buca ibag cali
	eststo childrenTobitEcu: bootstrap remit=r(APEremit), reps($reps) seed($seed) cluster(region_month_year): bootIVTobit	
	estimates save "$d_user/ChildrenTobitEcu", replace
	restore
	
eststo childrenLPMEcuedu1:  weakiv ivreg2 edu $FE (remit = UnempShock) if age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd
eststo childrenLPMEcuedu: weakiv ivreg2 edu $FE $x_variables $region_var (remit = UnempShock) if age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd
	
esttab childrenLPMEcu1 childrenLPMEcu  childrenTobitIV1 childrenTobitEcu childrenLPMEcuedu1 childrenLPMEcuedu ///
    using "$d_user/children_IV", replace label keep(remit) fragment booktabs stats(widstat ///
    ar_cset, labels("Kleibergen-Papp rk Wald F statistic" "Anderson-Rubin Test ") fmt(2)) ///
	cells(b(fmt(3)) se(par star fmt(3))) starlevels(* 0.1 ** 0.05 *** 0.01) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)
	
eststo averagehall: estpost sum h if sample & age<=18
eststo averagehoursall: estpost sum hours if sample & age<=18 & hours>0
eststo averageeduall: estpost sum edu if sample & age<=18 

esttab averagehall averagehoursall averageeduall ///
    using "$d_user/averagechildreniv", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)	
	
//Table 5

global x_variables age boy members tchildren femalehh marriedhh hhedu index hh_spouse shareExp
eststo childrenLPMEcu3: weakiv ivreg2 h $FE $x_variables  $region_var (remit = UnempShock) if age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd
global x_variables age boy members tchildren femalehh marriedhh hhedu index hh_spouse shareadults
eststo childrenLPMEcu4: weakiv ivreg2 h $FE $x_variables  $region_var (remit = UnempShock) if age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd
global x_variables age boy members tchildren femalehh marriedhh hhedu index hh_spouse shareExp shareadults
eststo childrenLPMEcu5: weakiv ivreg2 h $FE $x_variables $region_var (remit = UnempShock) if age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd

esttab childrenLPMEcu childrenLPMEcu3 childrenLPMEcu4 childrenLPMEcu5 ///
    using "$d_user/children_threats", replace label keep(remit shareExp shareadults) ///
    fragment booktabs stats(widstat ar_cset N, labels("Kleibergen-Papp rk Wald F statistic" "Anderson-Rubin Test " "Observations") fmt(2)) ///
	cells(b(fmt(3)) se(par star fmt(3))) starlevels(* 0.1 ** 0.05 *** 0.01) varwidth(15) mlabels(, none) collabels(none, none) plain ///
	substitute(_ \_ ) style(tex)	

//Table 6

global x_variables age boy members tchildren femalehh marriedhh hhedu index hh_spouse

*Panel A

eststo below15LPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=14 & sample, noconstant cluster(region_month_year)  ci level(90) estadd
eststo above16LPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>14 & age<=18 & sample, noconstant cluster(region_month_year)  ci level(90) estadd 
rivtest, ci level(90)
eststo boysLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=18 & boy==1 & sample, noconstant cluster(region_month_year) ci level(90) estadd
eststo girlsLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=18 & boy==0 & sample, noconstant cluster(region_month_year)  ci level(90) estadd
rivtest, ci level(90)

esttab below15LPMEcu above16LPMEcu boysLPMEcu girlsLPMEcu ///
    using  "$d_user/heteroLPMPanelA", replace label keep(remit) fragment booktabs ///
    stats(widstat ar_cset N, labels("Kleibergen-Papp rk Wald F statistic" "Anderson-Rubin Test " "Observations") fmt(2)) cells(b(fmt(3)) ///
    se(par star fmt(3))) starlevels(* 0.1 ** 0.05 *** 0.01) varwidth(15) mlabels(, none) collabels(, none) nonumbers plain substitute(_ \_ ) style(tex)
	
eststo averageboy: estpost sum h if sample & age<=18 & boy==1
eststo averagegirl: estpost sum h if sample & age<=18 & boy==0
eststo averagebelow15: estpost sum h if sample & age<=14
eststo averageabove16: estpost sum h if sample & age>14 & age<=18	

esttab averagebelow15 averageabove16 averageboy averagegirl using "$d_user/averageheteroPanelA", replace label ///
	fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain ///
	substitute(_ \_ ) style(tex)

*Panel B1

eststo youngboysLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=14 & boy==1 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo younggirlsLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=14 & boy==0 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo oldboysLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>14 & age<=18 & boy==1 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo oldgirlsLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>14 & age<=18 & boy==0 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)

esttab youngboysLPMEcu younggirlsLPMEcu oldboysLPMEcu oldgirlsLPMEcu ///
    using  "$d_user/heteroLPMPanelB", replace label keep(remit) fragment booktabs ///
    stats(widstat ar_cset, labels("Kleibergen-Papp rk Wald F statistic" "Anderson-Rubin Test ") fmt(2)) cells(b(fmt(3)) se(par star fmt(3))) ///
    starlevels(* 0.1 ** 0.05 *** 0.01) varwidth(15) mlabels(, none) collabels(, none) nonumbers plain substitute(_ \_ ) style(tex)
	
eststo averageboy14: estpost sum h if sample & age<=14 & boy==1
eststo averagegirl14: estpost sum h if sample & age<=14 & boy==0
eststo averageboy18: estpost sum h if sample & age>14 & age<=18 & boy==1
eststo averagegirl18: estpost sum h if sample & age>14 & age<=18 & boy==0

esttab averageboy14 averagegirl14 averageboy18 averagegirl18 ///
    using "$d_user/averageheteroPanelB", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)	
	
*Panel B2

eststo youngboyshousework: weakiv ivreg2 housework $x_variables $FE $region_var (remit = UnempShock) if boy==1 & age<=14 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo younggirlshousework: weakiv ivreg2 housework $x_variables $FE $region_var (remit = UnempShock) if boy==0 & age<=14 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo oldboyshousework: weakiv ivreg2 housework $x_variables $FE $region_var (remit = UnempShock) if boy==1 & age>14 & age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo oldgirlshousework: weakiv ivreg2 housework $x_variables $FE $region_var (remit = UnempShock) if boy==0 & age>14 & age<=18 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)

esttab youngboyshousework younggirlshousework oldboyshousework oldgirlshousework ///
    using "$d_user/housework_hetero", replace label keep(remit) fragment booktabs ///
    stats(widstat ar_cset N, labels("Kleibergen-Papp rk Wald F statistic" "Anderson-Rubin Test " "Observations") fmt(2)) cells(b(fmt(3)) se(par star fmt(3))) ///
    starlevels(* 0.1 ** 0.05 *** 0.01) varwidth(15) mlabels(, none) collabels(, none) nonumbers plain substitute(_ \_ ) style(tex)
	
eststo averageboy14house: estpost sum housework if sample & age<=14 & boy==1
eststo averagegirl14house: estpost sum housework if sample & age<=14 & boy==0
eststo averageboy18house: estpost sum housework if sample & age>14 & age<=18 & boy==1
eststo averagegirl18house: estpost sum housework if sample & age>14 & age<=18 & boy==0

esttab averageboy14house averagegirl14house averageboy18house averagegirl18house ///
    using "$d_user/averageheteroPanelC", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)	

//Table 7 Wealth analysis 

eststo poorLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=18 & poor==1 & sample, noconstant cluster(region_month_year)  ci level(90) estadd
rivtest, ci level(90)
eststo poorbelow15LPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=14 & poor==1 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo poorabove15LPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>14 & age<=18 & poor==1 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)

eststo nopoorLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=18 & poor==0 & sample, noconstant cluster(region_month_year)  ci level(90) estadd
rivtest, ci level(90)
eststo nopoorbelow15LPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age<=14 & poor==0 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo nopoorabove15LPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>14 & age<=18 & poor==0 & sample, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)

esttab poorLPMEcu nopoorLPMEcu poorbelow15LPMEcu nopoorbelow15LPMEcu poorabove15LPMEcu nopoorabove15LPMEcu ///
    using  "$d_user/wealthLPM", replace label keep(remit) fragment booktabs ///
    stats(widstat ar_cset N, labels("Kleibergen-Papp rk Wald F statistic" "Anderson-Rubin Test " "Observations") fmt(2)) cells(b(fmt(3)) se(par star fmt(3))) ///
    starlevels(* 0.1 ** 0.05 *** 0.01) varwidth(15) mlabels(, none) collabels(, none) substitute(_ \_ ) style(tex)
    
eststo averagepoor: estpost sum h if sample & age<=18 & poor==1
eststo averagepooryoung: estpost sum h if sample & age<=14 & poor==1
eststo averagepoorold: estpost sum h if sample & age>14 & age<=18 & poor==1
eststo averagenopoor: estpost sum h if sample & age<=18 & poor==0
eststo averagenopooryoung: estpost sum h if sample & age<=14 & poor==0
eststo averagenopoorold: estpost sum h if sample & age>14 & age<=18 & poor==0

esttab averagepoor averagenopoor averagepooryoung averagenopooryoung averagepoorold averagenopoorold ///
    using "$d_user/averagewealth", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)    

//Table 8

eststo alladultsLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>18 & sampHH, noconstant cluster(region_month_year) ci level(90) estadd 
rivtest, ci level(90)
eststo menadultsLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>18 & boy==1 & sampHH, noconstant cluster(region_month_year) ci level(90) estadd 
eststo womenadultsLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>18 & boy==0 & sampHH, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)
eststo pooradultsLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>18 & poor==1 & sampHH, noconstant cluster(region_month_year) ci level(90) estadd 
rivtest, ci level(90)
eststo nopooradultsLPMEcu: weakiv ivreg2 h $x_variables $FE $region_var (remit = UnempShock) if age>18 & poor==0 & sampHH, noconstant cluster(region_month_year) ci level(90) estadd
rivtest, ci level(90)

esttab childrenLPMEcu alladultsLPMEcu menadultsLPMEcu womenadultsLPMEcu pooradultsLPMEcu nopooradultsLPMEcu ///
    using "$d_user/adultshetero", replace label keep(remit) fragment booktabs stats(widstat ar_cset N, ///
    labels("Kleibergen-Papp rk Wald F statistic" "Anderson-Rubin Test " "Observations") fmt(2)) cells(b(fmt(3)) se(par star fmt(3))) ///
    starlevels(* 0.1 ** 0.05 *** 0.01) varwidth(15) mlabels(, none) collabels(, none) substitute(_ \_ ) style(tex)
	
eststo averageall: estpost sum h if sample & age<=18
eststo averageadultssample: estpost sum h if sampHH & age>18
eststo averagemensample: estpost sum h if sampHH & age>18 & boy==1
eststo averagewomensample: estpost sum h if sampHH & age>18 & boy==0	
eststo averagepoorsample: estpost sum h if sampHH & age>18 & poor==1
eststo averagenopoorsample: estpost sum h if sampHH & age>18 & poor==0		

esttab averageall averageadultssample averagemensample averagewomensample averagepoorsample averagenopoorsample ///
    using "$d_user/averageadultshetero", replace label fragment booktabs cells(mean(fmt(3))) ///
	varwidth(15) mlabels(, none) collabels(none, none) noobs nonumbers plain substitute(_ \_ ) style(tex)

         
